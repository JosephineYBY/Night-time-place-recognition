function mac_corr_coeff = Find_Best_Patch_Match(im1,im2,n)

%% crop the im1 into nxn patches

im1_crop = cell(n);
im1_crop_ave = ones(n);

r = round(linspace(1,size(im1,1),n+1));
c = round(linspace(1,size(im1,2),n+1));

for i = 1:n
    for j = 1:n
        im1_crop{i,j} = im1(r(i):r(i+1),c(j):c(j+1));
        im1_crop_ave(i,j) = mean(mean(im1_crop{i,j}));
        %[r(i) r(i+1),c(j) c(j+1)]
    end
end

%% find the best patch by seeing where most features exists
 [minV, idx] = min(im1_crop_ave(:));
 
 patch = im1_crop{idx};
 
 %% use best patch to find score of matching
 if size(patch,1)> size(im2,1) | size(patch,2)> size(im2,2)
     patch = imresize(patch,round([size(im2)]/4));
 end
 c = normxcorr2(patch,im2);
 [ypeak, xpeak] = find(c==max(c(:)));
mac_corr_coeff = max(c(:));
yoffSet = ypeak-size(patch,1);
xoffSet = xpeak-size(patch,2);

% 
% figure
% subplot(1,2,1)
% imshow(im2);
% imrect(gca, [xoffSet, yoffSet, size(patch,2), size(patch,1)]);
% title('Best Patch Match in Test Image')
% 
% subplot(1,2,2)
% imshow(im1);
% imrect(gca, [xoffSet, yoffSet, size(patch,2), size(patch,1)]);
% title('Template From Image')

end
function output = Edge_test(im1,im2)

% im1 is usualy set to the night time image
% im2 is the testing image

% image enhancement
% im1_enh = imsharpen(imguidedfilter(adapthisteq(rgb2gray(im1))));
% im2_enh = imsharpen(imguidedfilter(adapthisteq(rgb2gray(im2))));
% 
im1_enh = imsharpen(imguidedfilter(histeq(rgb2gray(im1))));
im2_enh = imsharpen(imguidedfilter(histeq(rgb2gray(im2))));

% im1_enh = rgb2gray(im1);
% im2_enh = rgb2gray(im2);

%% edge detection
im1_edge = edge(im1_enh,'Canny',[1e-6 .4],2);
im2_edge = edge(im2_enh,'Canny',[1e-6 .4],2);


%% distance transform
im1_dist = bwdist(im1_edge); 
im1_dist_norm = im1_dist*10/max(max(im1_dist));

im2_dist = bwdist(im2_edge); 
im2_dist_norm = im2_dist*10/max(max(im2_dist));

%% crop the image for best features

output = Find_Best_Patch_Match(im1_dist_norm,im2_dist_norm,2);
% output = Find_Best_Patch_Match(im1_edge,im2_edge,2);

%% Plots
% figure
% subplot(3,2,1);imshow(im1_enh);         subplot(3,2,2);imshow(im2_enh);
% subplot(3,2,3);imshow(im1_edge);        subplot(3,2,4);imshow(im2_edge);
% subplot(3,2,5);imshow(im1_dist_norm);   subplot(3,2,6);imshow(im2_dist_norm);
%% Sum of absolute differences
%output = abs(sum(sum(imresize(im2_dist_norm,size(im1_dist_norm))-im1_dist_norm)));
end

%{

close all
imshow(im1_edge)
figure
imshow(im2_edge)  



%}



% for k = 10
  %labels = top_ten_images_idx;

% for all returns
[B,I] = sort(all_scores3,2,'descend');
labels = I(:,2:end);

% lablels:
% 1 = scene 17
% 2 = scene 7

labels(labels<=76) = 1;
labels(labels>76) = 2;

for i = 1:size(labels,1)
    % one row at a time, row number is image number used for query
    set = labels(i,:);
    
    % condition if test image is from scene 1 or 2
    if i <=76
        searchFor = 1;
    else
        searchFor = 2;
    end
    
    % find indices where true matches were found
    true_indices = find(set==searchFor);
    
    
    % divide the index of trues by the true indices found in set
    precisions = [1:length(true_indices)] ./ true_indices;
    
    average_precision(i) = mean(precisions);
end

average_precision(isnan(average_precision))=0;
mean_average_precision = mean(average_precision)


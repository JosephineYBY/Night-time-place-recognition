%% READ ME

%{

The image datasets were all loaded onto the workspace and saved to a .mat
file. The following code was then ran. Precision was claculated using the
M\ap script. teh two functions Edge_test and Find_Best_Patch were the main
functions of the algorithm. 






%}


%% Actual Code
% files = dir('*.jpg');
% numfiles = length(files);
% data = cell(1,numfiles);
% 
% for i = 1:numfiles
%     scene17{i} = imread(files(i).name);
% 
% end
 % test scenes 16 and 7
%data = scene16;

% scene17 = 00023966
% scene7 = 00005381
% test = [scene17 scene7];
% scene17_end = 76;

% for i = 1:length(data)
% same_class(i) = Edge_test(data{2},data{i});
% %image_contrast(i) = mean(data{i}(:));
% end
top_ten_scores = zeros(length(test),10);
top_ten_images_idx = zeros(length(test),10);
max_corr_scores = zeros(1,length(test));
all_scores = zeros(length(test));
% go through each image for it to be tested

for test_image = length(test):-1:1
%for test_image = 1
    % go through query of other images
    for i = 1:length(test)
        max_corr_scores(i) = Edge_test(test{test_image},test{i});
    %disp(max_corr_scores(i))
    end
% find the best 100 scores, remove first score since it is itself
all_scores(test_image,:) = max_corr_scores;
[B,I] = maxk(max_corr_scores,11);
B = B(2:end);I = I(2:end);
% save the top 10 scores and image indices
top_ten_scores(test_image,:) = B;
top_ten_images_idx(test_image,:) = I;
%acc = sum(I<truths)/length(I);


 X = [num2str(test_image),' out of ',num2str(length(test))];
 disp(X)  
end
%%
save('scores_n2_threshold_point4_2_equalHist_151to171.mat','all_scores','top_ten_scores','top_ten_images_idx')
disp('Finished Saving')
% plot(diff_class)
% hold on
% xline(93);